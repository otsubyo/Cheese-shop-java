package application;

public class FromageALUnit� extends Fromage {
	
	public FromageALUnit�(String d�signation) {
		super(d�signation);
	}

	public String toString() {
		return super.toString() + ", vendu à l'unit�";
	}

}
